package com.bvk.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GivaApplicationTests {

	@Test
	void contextLoads() {
	}

}
