package com.bvk.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class IndexService {
    @Autowired
	private DataRepository dataRepo;
    public DataEntity save(DataEntity data) {
		return dataRepo.save(data);
	}
	
	public List<DataEntity> findAll(){
		return dataRepo.findAll();
	}
	
	public DataEntity findById(Long id) {
		return (DataEntity) ((Object) dataRepo.findById(id));
	}
	
	public void removeOne(Long app_id) {
		dataRepo.deleteById(app_id);
	}
	
	public DataEntity findDataByname(String name) {
		return dataRepo.findDataByName(name);
	}
	
	public List<DataEntity> findDataByNameLike(String name) {
		return (List<DataEntity>) dataRepo.findDataByName("%"+name+"%");
	}
	
	public List<DataEntity> findByNameAndAddress(String name, String address){
		return dataRepo.findByNameAndAddress(name, address);
	}
	
	
	
}

