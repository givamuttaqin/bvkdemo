package com.bvk.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.beans.factory.annotation.Autowired;
/**
 *
 * @author Giva
 */

@Controller

public class IndexController {
@Autowired

    @GetMapping("/index")
    public String index(Model model){
        return "index"; 
    }
    @GetMapping("/login")
      public String login(Model model){
      return "login";
  }
}