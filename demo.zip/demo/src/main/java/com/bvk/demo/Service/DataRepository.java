package com.bvk.demo.Service;

import java.util.List;

public class DataRepository {

    public DataEntity save(DataEntity data) {
        return null;
    }

    public List<DataEntity> findAll() {
        return null;
    }

    public Object findById(Long id) {
        return null;
    }

    public void deleteById(Long app_id) {
    }

    public DataEntity findDataByName(String name) {
        return null;
    }

    public List<DataEntity> findByNameAndAddress(String name, String address) {
        return null;
    }

}
