package com.bvk.demo.Service;

public class DataEntity {

}
